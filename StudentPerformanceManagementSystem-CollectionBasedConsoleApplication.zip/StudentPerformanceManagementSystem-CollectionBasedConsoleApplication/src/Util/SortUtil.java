package Util;

import Model.Student;

import java.util.Comparator;

public class SortUtil {
    public static Comparator<Student> byName = (a,b) -> a.getName().compareToIgnoreCase(b.getName());

    public static Comparator<Student> byAverage = (a,b) -> Double.compare(b.getAverage(),a.getAverage());
}
