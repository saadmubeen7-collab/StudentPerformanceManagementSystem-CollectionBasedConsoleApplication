package Model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Student implements Comparable<Student>{

    private int id;
    private String name;
    private Map<String,Integer> subjectMarks;
    private Set<String> subjects;

    public Student(int id, String name){
        this.id=id;
        this.name=name;
        this.subjectMarks= new HashMap<>();
        this.subjects = new HashSet<>();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Map<String, Integer> getSubjectMarks() {
        return subjectMarks;
    }
    public Set<String> getSubjects(){
        return subjects;
    }
    public void addOrUpdateMarks(String subject,int marks){
        if(marks<0 || marks>100){
            throw new IllegalArgumentException("Marks must be between 0 and 100");
        }
        if (subject == null || subject.trim().isEmpty()) {
            throw new IllegalArgumentException("Subject cannot be null or empty");
        }
        if (!subject.matches("[a-zA-Z ]+")) {
            throw new IllegalArgumentException("Invalid subject name");
        }
        subjects.add(subject);
        subjectMarks.put(subject,marks);
    }
    public double getAverage(){
        if(subjectMarks.isEmpty())
            return 0.0;
        double sum=0.0;
        for(int m : subjectMarks.values()){
            sum +=m;
        }
        return sum/subjectMarks.size();
    }

    public String getGrade(){
        double avg = getAverage();
        if( avg>=90)
            return "A";
        if( avg>=75)
            return "B";
        if( avg>=60)
            return "C";
        return "D";
    }

    @Override
    public int compareTo(Student o) {

        return Integer.compare(this.id,o.id);
    }

    @Override
    public String toString() {
        return "ID=" + id + ", Name=" + name +
                ", Avg=" + getAverage() +
                ", Grade=" + getGrade();
    }
}
