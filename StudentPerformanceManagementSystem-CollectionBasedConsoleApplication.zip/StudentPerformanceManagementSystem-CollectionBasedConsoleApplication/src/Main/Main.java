package Main;

import Model.Student;
import Exception.DuplicateStudentException;
import Service.StudentService;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentService service = new StudentService();

        while(true){
            System.out.println("STUDENT PERFORMANCE MANAGEMENT SYSTEM");
            System.out.println("\n1. Add Student  \n2. Add Marks  \n3. View Details \n4. Delete Student \n5. Search Student  \n6.Sort Students \n7. Top Performers  \n8. Exit Console ");
            int choice  = sc.nextInt();

            try{
                switch(choice){

                    case 1:
                        System.out.print("ID: ");
                        int id = sc.nextInt();
                        System.out.print("Name: ");
                        String name = sc.next();
                        service.addStudent(id,name);
                        break;

                    case 2:
                        System.out.print("ID: ");
                        int sid = sc.nextInt();
                        System.out.print("Subject: ");
                        String sub = sc.next();
                        System.out.print("Marks: ");
                        int marks = sc.nextInt();
                        service.addMarks(sid, sub, marks);
                        break;

                    case 3:
                        System.out.print("ID: ");
                        service.viewStudent(sc.nextInt());
                        break;

                    case 4:
                        System.out.print("ID: ");
                        service.deleteStudent(sc.nextInt());
                        break;

                    case 5:
                        System.out.print("ID: ");
                        Student s = service.searchStudent(sc.nextInt());
                        System.out.println(s != null ? s : "Not Found");
                        break;

                    case 6:
                        System.out.println("\n1.ID \n2.Name \n3.Avg");
                        List<Student> sorted = service.getSortedStudents(sc.nextInt());
                        sorted.forEach(System.out::println);
                        break;

                    case 7:
                        System.out.print("Top N: ");
                        List<Student> top = service.getTopPerformer(sc.nextInt());
                        top.forEach(System.out::println);
                        break;

                    case 8:
                        System.exit(0);
                }
            } catch (DuplicateStudentException e){
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Invalid Input");
            }
        }
    }
}
