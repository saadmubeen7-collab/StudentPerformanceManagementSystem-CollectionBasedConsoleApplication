package Service;

import Model.Student;

import java.util.*;

import Exception.*;
import Util.SortUtil;

import static Util.SortUtil.byAverage;
import static Util.SortUtil.byName;

public class StudentService {

    private Map<Integer ,Student> studentMap = new HashMap<>();

    public void addStudent(int id , String name) throws DuplicateStudentException {
        if(studentMap.containsKey(id)){
            throw new DuplicateStudentException("Student ID Already Exists");
        }
        studentMap.put(id, new Student(id, name));
        System.out.println("Student Added Successfully");
    }

    public void addMarks(int id, String subject, int marks){
        Student s = studentMap.get(id);
        if(s == null){
            System.out.println("Student not found");
            return;
        }
        s.addOrUpdateMarks(subject, marks);
        System.out.println("Marks Added Successfully");
    }

    public void viewStudent(int id){
        Student s = studentMap.get(id);
        if(s ==  null){
            System.out.println("Student not found!");
            return;
        }
        System.out.println(s);
        for(Map.Entry<String, Integer> e : s.getSubjectMarks().entrySet()){
            System.out.println(e.getKey() + " : " + e.getValue());
        }
    }

    public void deleteStudent(int id){
        Iterator<Map.Entry<Integer, Student>> it = studentMap.entrySet().iterator();

        while(it.hasNext()){
            Map.Entry<Integer, Student> entry = it.next();
            if(entry.getKey() == id){
                it.remove();
                System.out.println("Student Removed!");
                return;
            }
        }
        System.out.println("Student not found");
    }
    public Student searchStudent(int id){
        return studentMap.get(id);
    }

    public List<Student> getSortedStudents(int type){
        List<Student> list = new ArrayList<>(studentMap.values());

        switch (type){
            case 1:
                Collections.sort(list);
                break;
            case 2:
                list.sort(byName);
                break;
            case 3:
                list.sort(byAverage);
                break;
        }
        return list;
    }

    public List<Student> getTopPerformer(int  n){
        PriorityQueue<Student> pq = new PriorityQueue<>(byAverage);
        pq.addAll(studentMap.values());
        List<Student> result = new ArrayList<>();
        while (n > 0 && !pq.isEmpty()) {
            result.add(pq.poll());
            n--;
        }
        return result;
    }
    public boolean isEmpty() {
        return studentMap.isEmpty();
    }

}
